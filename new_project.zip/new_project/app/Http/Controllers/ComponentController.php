<?php
namespace App\Http\Controllers;
class ComponentController extends Controller
{


	function indexfunction()
	{
		return view('component.grid');
	}

	public function media()
	{
		return view('component.media');
	}

}

