<div class="footer">
	<p>&copy; 2018 Glance Design Dashboard. All Rights Reserved | Design by </p>  
</div>