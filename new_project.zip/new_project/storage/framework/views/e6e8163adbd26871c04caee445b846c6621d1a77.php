  <aside class="sidebar-left">
    <nav class="navbar navbar-inverse">
     <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
       <span class="sr-only">Toggle navigation</span>
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
     </button>
     <h1><a class="navbar-brand" href="index.html"><span class="fa fa-area-chart"></span> Glance<span class="dashboard_text">Design dashboard</span></a></h1>
   </div>
   <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="sidebar-menu">
     <li class="header">MAIN NAVIGATION</li>
     <li class="treeview">
      <a href="index.html">
       <i class="fa fa-dashboard"></i> <span>Dashboard</span>
     </a>
   </li>
   <li class="treeview">
    <a href="">
     <i class="fa fa-laptop"></i>
     <span>Components</span>
     <i class="fa fa-angle-left pull-right"></i>
     <small class="label pull-right label-info">02</small>

   </a>
   <ul class="treeview-menu">
     <li>
      <a href="<?php echo e(URL('/component/grid')); ?>">
        <i class="fa fa-angle-right"></i> Grids</a></li>
        <li><a href="<?php echo e(URL('/component/media')); ?>"><i class="fa fa-angle-right"></i> Media Css</a></li>
      </ul>
    </li>



  </ul>
</div>
</nav>
</aside>
<?php /* C:\xampp\htdocs\new_project\resources\views/layout/sidebar.blade.php */ ?>